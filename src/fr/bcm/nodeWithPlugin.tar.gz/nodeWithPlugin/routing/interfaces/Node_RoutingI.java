package fr.bcm.nodeWithPlugin.routing.interfaces;

import fr.bcm.nodeWithPlugin.routing.plugins.Node_RoutingP;

public interface Node_RoutingI {
	public Node_RoutingP getPlugin();
}
