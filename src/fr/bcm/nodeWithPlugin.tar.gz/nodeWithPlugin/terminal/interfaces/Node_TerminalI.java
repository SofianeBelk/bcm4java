package fr.bcm.nodeWithPlugin.terminal.interfaces;

import fr.bcm.nodeWithPlugin.terminal.plugins.Node_TerminalP;

public interface Node_TerminalI {
	public Node_TerminalP getPlugin();
}
